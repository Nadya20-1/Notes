package com.example.notes

import android.app.Activity
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.notes.model.Notes
import com.example.notes.ui.base.BaseActivity

import com.example.notes.ui.viewmodel.NotesViewModel

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : BaseActivity(), OnDeleteClickListener {

    private lateinit var viewModel: NotesViewModel
    private lateinit var adapter: NoteMainAdapter
    private lateinit var itemSearch: SearchView
    private val newNoteActivityRequestCode = 1


    override fun getViewID(): Int = R.layout.activity_main

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setSupportActionBar(toolbar)
        supportActionBar?.title = "Notes"

        viewModel = ViewModelProvider(this).get(NotesViewModel::class.java)

        adapter = NoteMainAdapter(this, this)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        viewModel.getAllNotes().observe(this,
            Observer {
                adapter.setNotesList(it)
            }
        )

        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT.or(ItemTouchHelper.RIGHT)) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                viewModel.deleteNote(adapter.getNoteAt(viewHolder.adapterPosition))
                Toast.makeText(baseContext, "Note Deleted!", Toast.LENGTH_SHORT).show()
            }
        }
        ).attachToRecyclerView(recyclerView)

        adapter.setOnItemClickListener(object : NoteMainAdapter.OnItemClickListener {
            override fun onItemClick(note: Notes) {
                val intent = Intent(baseContext, NewNoteActivity::class.java)
                intent.putExtra(NewNoteActivity.EXTRA_REPLAY_TITLE, note.title)
                intent.putExtra(NewNoteActivity.EXTRA_REPLAY_DESCRIPTION, note.description)
                intent.putExtra(NewNoteActivity.EXTRA_REPLAY_COLOR, note.color)

                startActivityForResult(intent, EDIT_NOTE_REQUEST)
            }
        })
    }

    override fun onResume() {
        super.onResume()

        fab.setOnClickListener {
            val intent = Intent(this, NewNoteActivity::class.java)
            startActivityForResult(intent, newNoteActivityRequestCode)
            ADD_NOTE_REQUEST
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(requestCode == newNoteActivityRequestCode && resultCode == Activity.RESULT_OK) {
            val title = data?.getStringExtra(NewNoteActivity.EXTRA_REPLAY_TITLE).toString()
            val description = data?.getStringExtra(NewNoteActivity.EXTRA_REPLAY_DESCRIPTION).toString()
            val color = data?.getStringExtra(NewNoteActivity.EXTRA_REPLAY_COLOR).toString().toInt()
            val note = Notes(
                0,
                title,
                description,
                color,
                getDateTime()
            )
            viewModel.insertNote(note)
            Log.d("TAG", "$title - $description")
        } else if (requestCode == EDIT_NOTE_REQUEST && resultCode == Activity.RESULT_OK) {

            val title = data?.getStringExtra(NewNoteActivity.EXTRA_REPLAY_TITLE).toString()
            val description = data?.getStringExtra(NewNoteActivity.EXTRA_REPLAY_DESCRIPTION).toString()
            val color = data?.getStringExtra(NewNoteActivity.EXTRA_REPLAY_COLOR).toString().toInt()
            val note = Notes(
                0,
                title,
                description,
                color,
                getDateTime()
            )
            viewModel.update(note)

        } else {
            showToast("Note not saved!")
        }
    }

    override fun onclick(note: Notes) {
        viewModel.deleteNote(note)
    }

    // -- Menu Option: Delete All and SearchView ---
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_main, menu)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val item = menu.findItem(R.id.searchItem)
        itemSearch = item.actionView as SearchView
        itemSearch.setSearchableInfo(searchManager.getSearchableInfo(componentName))

        itemSearch.setOnQueryTextListener(
            object : SearchView.OnQueryTextListener{
                override fun onQueryTextSubmit(query: String?): Boolean {
                    adapter.filter.filter(query)
                    return false
                }
                override fun onQueryTextChange(query: String?): Boolean {
                    adapter.filter.filter(query)
                    return false
                }
            }
        )
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.searchItem -> {
                return true
            }
            R.id.deleteAll -> {
                showToast("Delete All Items")
                viewModel.deleteAllNotes()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    companion object {
        const val ADD_NOTE_REQUEST = 1
        const val EDIT_NOTE_REQUEST = 2
    }
}

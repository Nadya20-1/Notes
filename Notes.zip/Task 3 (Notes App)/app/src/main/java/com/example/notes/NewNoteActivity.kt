package com.example.notes

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Toast
import com.example.notes.ui.base.BaseActivity
import dev.sasikanth.colorsheet.ColorSheet
import kotlinx.android.synthetic.main.activity_new_note.*

class NewNoteActivity : BaseActivity(){

    private var selectedColor: Int = ColorSheet.NO_COLOR

    override fun getViewID(): Int = R.layout.activity_new_note

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setSupportActionBar(toolBar2)
        supportActionBar?.title = "New Note"

        if (intent.hasExtra(EXTRA_ID)) {
            title = "Edit Note"
            editText_new_title.setText(intent.getStringExtra(EXTRA_REPLAY_TITLE))
            editText_new_description.setText(intent.getStringExtra(EXTRA_REPLAY_DESCRIPTION))
        } else {
            title = "Add Note"
        }

        saveFloatButton.setOnClickListener {
            val replayIntent = Intent()
            if(TextUtils.isEmpty(editText_new_title.text) || TextUtils.isEmpty(editText_new_description.text)) {
                setResult(Activity.RESULT_CANCELED, replayIntent)
            }else {
                replayIntent.putExtra(EXTRA_REPLAY_TITLE, editText_new_title.text.toString())
                replayIntent.putExtra(EXTRA_REPLAY_DESCRIPTION, editText_new_description.text.toString())
                replayIntent.putExtra(EXTRA_REPLAY_COLOR, selectedColor.toString())
                setResult(Activity.RESULT_OK, replayIntent)
            }
            finish()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_note_item, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.colorPicked -> {
                saveNote()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun saveNote() {
        if (editText_new_title.text.toString().trim().isBlank() || editText_new_description.text.toString().trim().isBlank()) {
            Toast.makeText(this, "Can not insert empty note!", Toast.LENGTH_SHORT).show()
            return
        }

        val data = Intent().apply {
            putExtra(EXTRA_REPLAY_TITLE, editText_new_title.text.toString())
            putExtra(EXTRA_REPLAY_DESCRIPTION, editText_new_description.text.toString())
            if (intent.getIntExtra(EXTRA_ID, -1) != -1) {
                putExtra(EXTRA_ID, intent.getIntExtra(EXTRA_ID, -1))
            }
        }

        setResult(Activity.RESULT_OK, data)
        finish()
    }

    companion object {
        const val EXTRA_ID = "EXTRA_ID"
        const val EXTRA_REPLAY_TITLE = "REPLAY_TITLE"
        const val EXTRA_REPLAY_DESCRIPTION = "REPLAY_DESCRIPTION"
        const val EXTRA_REPLAY_COLOR = "REPLAY_COLOR"
    }
}

